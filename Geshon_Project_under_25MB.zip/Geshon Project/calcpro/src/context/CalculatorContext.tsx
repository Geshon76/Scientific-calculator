import React, { createContext, useContext } from 'react';
import { useCalculator } from '../hooks/useCalculator';

type CalculatorContextType = ReturnType<typeof useCalculator>;

const CalculatorContext = createContext<CalculatorContextType | null>(null);

export const CalculatorProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const calc = useCalculator();
  return (
    <CalculatorContext.Provider value={calc}>
      {children}
    </CalculatorContext.Provider>
  );
};

export function useCalculatorContext(): CalculatorContextType {
  const ctx = useContext(CalculatorContext);
  if (!ctx) throw new Error('useCalculatorContext must be used inside <CalculatorProvider>');
  return ctx;
}
