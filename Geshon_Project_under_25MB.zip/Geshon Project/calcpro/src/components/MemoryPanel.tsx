import React from 'react';
import { CalculatorButton } from './CalculatorButton';

interface MemoryPanelProps {
  memory: number;
  hasMemory: boolean;
  onMS: () => void;
  onMR: () => void;
  onMC: () => void;
  onMPlus: () => void;
  onMMinus: () => void;
}

export const MemoryPanel: React.FC<MemoryPanelProps> = ({
  memory, hasMemory, onMS, onMR, onMC, onMPlus, onMMinus,
}) => (
  <div className="mb-2 px-1">
    {hasMemory && (
      <div className="flex items-center gap-2 mb-2 px-3 py-1.5 bg-amber-500/10 border border-amber-500/20 rounded-lg">
        <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
        <span className="text-amber-300 text-xs font-mono">
          M = {memory.toLocaleString('en-US', { maximumFractionDigits: 10 })}
        </span>
      </div>
    )}
    <div className="grid grid-cols-5 gap-1.5">
      <CalculatorButton label="MC"  onClick={onMC}      variant="memory" tooltip="Memory Clear"    id="btn-mc"     />
      <CalculatorButton label="MR"  onClick={onMR}      variant="memory" tooltip="Memory Recall"   id="btn-mr"     />
      <CalculatorButton label="MS"  onClick={onMS}      variant="memory" tooltip="Memory Store"    id="btn-ms"     />
      <CalculatorButton label="M+"  onClick={onMPlus}   variant="memory" tooltip="Memory Add"      id="btn-mplus"  />
      <CalculatorButton label="M−"  onClick={onMMinus}  variant="memory" tooltip="Memory Subtract" id="btn-mminus" />
    </div>
  </div>
);
