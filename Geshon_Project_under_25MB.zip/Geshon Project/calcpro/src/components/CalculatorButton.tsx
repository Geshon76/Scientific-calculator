import React from 'react';

type Variant =
  | 'default' | 'operator' | 'equals'
  | 'action'  | 'function' | 'memory'
  | 'second'  | 'active'   | 'constant';

interface CalculatorButtonProps {
  label: string;
  onClick: () => void;
  variant?: Variant;
  colSpan?: number;
  tooltip?: string;
  disabled?: boolean;
  id?: string;
}

const VARIANT_CLASSES: Record<Variant, string> = {
  default:  'bg-gray-700/80 hover:bg-gray-600/80 text-white border border-white/5 hover:border-white/15',
  operator: 'bg-violet-600/80 hover:bg-violet-500/80 text-white border border-violet-500/30 hover:border-violet-400/50',
  equals:   `bg-gradient-to-br from-violet-500 to-indigo-600 hover:from-violet-400 hover:to-indigo-500
             text-white font-bold border border-violet-400/40 shadow-lg shadow-violet-500/30`,
  action:   'bg-rose-600/80 hover:bg-rose-500/80 text-white border border-rose-500/30 hover:border-rose-400/50',
  function: 'bg-indigo-700/60 hover:bg-indigo-600/70 text-indigo-200 hover:text-white border border-indigo-500/20 hover:border-indigo-400/40 text-xs',
  memory:   'bg-amber-700/60 hover:bg-amber-600/70 text-amber-200 hover:text-white border border-amber-500/20 hover:border-amber-400/40 text-xs',
  second:   'bg-cyan-700/60 hover:bg-cyan-600/70 text-cyan-200 hover:text-white border border-cyan-500/20 hover:border-cyan-400/40',
  active:   'bg-cyan-500 text-white border border-cyan-400/60 shadow-lg shadow-cyan-500/40',
  constant: 'bg-teal-700/60 hover:bg-teal-600/70 text-teal-200 hover:text-white border border-teal-500/20 hover:border-teal-400/40',
};

export const CalculatorButton: React.FC<CalculatorButtonProps> = ({
  label, onClick, variant = 'default', colSpan = 1,
  tooltip, disabled = false, id,
}) => (
  <button
    id={id}
    onClick={onClick}
    disabled={disabled}
    title={tooltip ?? label}
    aria-label={tooltip ?? label}
    className={`
      relative overflow-hidden rounded-xl py-3 px-1 text-sm font-semibold
      transition-all duration-150 active:scale-95 active:brightness-90
      focus:outline-none focus:ring-2 focus:ring-violet-400/60 focus:ring-offset-1 focus:ring-offset-transparent
      disabled:opacity-40 disabled:cursor-not-allowed select-none cursor-pointer
      ${VARIANT_CLASSES[variant]}
      ${colSpan === 2 ? 'col-span-2' : colSpan === 3 ? 'col-span-3' : ''}
    `}
    style={{ minHeight: '3rem' }}
  >
    {/* shimmer */}
    <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent
      -translate-x-full hover:translate-x-full transition-transform duration-500 pointer-events-none" />
    <span className="relative z-10 leading-none">{label}</span>
  </button>
);
