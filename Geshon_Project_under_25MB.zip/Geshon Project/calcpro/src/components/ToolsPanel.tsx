import React, { useState } from 'react';
import { EXAMPLE_CALCULATIONS } from '../utils/constants';
import { Percent, BarChart2, ArrowLeftRight, Zap } from 'lucide-react';
import type { LengthUnit, TemperatureUnit, WeightUnit } from '../types/calculator';

// ─── Percentage Calculator ───────────────────────────────────────────────────

const PercentageCalculator: React.FC = () => {
  const [percent, setPercent] = useState('');
  const [value,   setValue]   = useState('');
  const [result,  setResult]  = useState<string | null>(null);

  const calculate = () => {
    const p = parseFloat(percent);
    const v = parseFloat(value);
    if (isNaN(p) || isNaN(v)) { setResult('Invalid input'); return; }
    setResult(`${p}% of ${v} = ${(p / 100) * v}`);
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        {[
          { label: 'Percentage (%)', val: percent, set: setPercent, ph: 'e.g. 20'  },
          { label: 'Value',          val: value,   set: setValue,   ph: 'e.g. 500' },
        ].map(({ label, val, set, ph }) => (
          <div key={label}>
            <label className="block text-xs text-gray-400 mb-1">{label}</label>
            <input
              type="number"
              value={val}
              onChange={e => set(e.target.value)}
              placeholder={ph}
              className="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-white text-sm
                focus:outline-none focus:border-violet-500 transition-colors"
            />
          </div>
        ))}
      </div>
      <button
        onClick={calculate}
        className="w-full py-2 bg-violet-600 hover:bg-violet-500 text-white rounded-lg text-sm font-semibold transition-colors"
      >
        Calculate
      </button>
      {result && (
        <div className="p-3 bg-violet-500/10 border border-violet-500/20 rounded-lg text-violet-200 text-sm font-mono">
          {result}
        </div>
      )}
    </div>
  );
};

// ─── Statistics Calculator ───────────────────────────────────────────────────

const StatisticsCalculator: React.FC = () => {
  const [input, setInput]   = useState('');
  const [stats, setStats]   = useState<null | {
    mean: number; median: number; min: number; max: number;
    sum: number; count: number; stdDev: number;
  }>(null);
  const [err, setErr] = useState('');

  const analyze = () => {
    const nums = input.split(/[,\s]+/).map(s => parseFloat(s.trim())).filter(n => !isNaN(n));
    if (!nums.length) { setErr('Enter valid numbers'); return; }
    setErr('');
    const sorted = [...nums].sort((a, b) => a - b);
    const sum    = nums.reduce((a, b) => a + b, 0);
    const mean   = sum / nums.length;
    const median = nums.length % 2 === 0
      ? (sorted[nums.length / 2 - 1] + sorted[nums.length / 2]) / 2
      : sorted[Math.floor(nums.length / 2)];
    const variance = nums.reduce((a, b) => a + (b - mean) ** 2, 0) / nums.length;
    setStats({ mean, median, min: sorted[0], max: sorted[sorted.length - 1], sum, count: nums.length, stdDev: Math.sqrt(variance) });
  };

  const fmt = (n: number) => parseFloat(n.toPrecision(8)).toString();

  return (
    <div className="space-y-3">
      <div>
        <label className="block text-xs text-gray-400 mb-1">Numbers (comma or space separated)</label>
        <textarea
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="e.g. 10, 20, 30, 40, 50"
          rows={2}
          className="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-white text-sm
            focus:outline-none focus:border-violet-500 transition-colors resize-none"
        />
      </div>
      {err && <p className="text-red-400 text-xs">{err}</p>}
      <button
        onClick={analyze}
        className="w-full py-2 bg-violet-600 hover:bg-violet-500 text-white rounded-lg text-sm font-semibold transition-colors"
      >
        Analyze
      </button>
      {stats && (
        <div className="grid grid-cols-2 gap-2">
          {([
            ['Count',   stats.count ],
            ['Sum',     fmt(stats.sum)    ],
            ['Mean',    fmt(stats.mean)   ],
            ['Median',  fmt(stats.median) ],
            ['Min',     fmt(stats.min)    ],
            ['Max',     fmt(stats.max)    ],
            ['Std Dev', fmt(stats.stdDev) ],
          ] as [string, string | number][]).map(([lbl, val]) => (
            <div key={lbl} className="p-2 bg-black/30 rounded-lg">
              <div className="text-gray-500 text-xs">{lbl}</div>
              <div className="text-white font-mono text-sm font-semibold">{val}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// ─── Unit Converter ──────────────────────────────────────────────────────────

const toMeters:  Record<LengthUnit,      number> = { mm: 0.001, cm: 0.01, m: 1, km: 1000, inch: 0.0254, ft: 0.3048, mile: 1609.344 };
const toGrams:   Record<WeightUnit,      number> = { mg: 0.001, g: 1, kg: 1000, lb: 453.592, oz: 28.3495 };

const UnitConverter: React.FC = () => {
  const [category, setCategory] = useState<'length' | 'temperature' | 'weight'>('length');
  const [fromUnit, setFromUnit] = useState('m');
  const [toUnit,   setToUnit]   = useState('km');
  const [inputVal, setInputVal] = useState('');
  const [output,   setOutput]   = useState('');

  const lengthUnits: LengthUnit[]      = ['mm', 'cm', 'm', 'km', 'inch', 'ft', 'mile'];
  const tempUnits:   TemperatureUnit[] = ['celsius', 'fahrenheit', 'kelvin'];
  const weightUnits: WeightUnit[]      = ['mg', 'g', 'kg', 'lb', 'oz'];

  const currentUnits = category === 'length' ? lengthUnits : category === 'temperature' ? tempUnits : weightUnits;

  const switchCategory = (cat: typeof category) => {
    setCategory(cat);
    setInputVal(''); setOutput('');
    if (cat === 'length')      { setFromUnit('m');       setToUnit('km');         }
    if (cat === 'temperature') { setFromUnit('celsius'); setToUnit('fahrenheit'); }
    if (cat === 'weight')      { setFromUnit('kg');      setToUnit('lb');         }
  };

  const convert = () => {
    const val = parseFloat(inputVal);
    if (isNaN(val)) { setOutput('Invalid'); return; }
    let result: number;
    if (category === 'length') {
      result = val * toMeters[fromUnit as LengthUnit] / toMeters[toUnit as LengthUnit];
    } else if (category === 'weight') {
      result = val * toGrams[fromUnit as WeightUnit] / toGrams[toUnit as WeightUnit];
    } else {
      let c: number;
      if (fromUnit === 'celsius')    c = val;
      else if (fromUnit === 'fahrenheit') c = (val - 32) * 5 / 9;
      else                           c = val - 273.15;
      if (toUnit === 'celsius')      result = c;
      else if (toUnit === 'fahrenheit') result = c * 9 / 5 + 32;
      else                           result = c + 273.15;
    }
    setOutput(parseFloat(result.toPrecision(10)).toString());
  };

  return (
    <div className="space-y-3">
      <div className="flex gap-1">
        {(['length', 'temperature', 'weight'] as const).map(c => (
          <button
            key={c}
            onClick={() => switchCategory(c)}
            className={`flex-1 py-1.5 rounded-lg text-xs font-semibold capitalize transition-colors ${
              category === c ? 'bg-violet-600 text-white' : 'bg-black/30 text-gray-400 hover:text-white'
            }`}
          >
            {c}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-2">
        {(['From', 'To'] as const).map((lbl, idx) => {
          const curr = idx === 0 ? fromUnit : toUnit;
          const set  = idx === 0 ? setFromUnit : setToUnit;
          return (
            <div key={lbl}>
              <label className="block text-xs text-gray-400 mb-1">{lbl}</label>
              <select
                value={curr}
                onChange={e => set(e.target.value)}
                className="w-full bg-black/40 border border-white/10 rounded-lg px-2 py-2 text-white text-sm
                  focus:outline-none focus:border-violet-500 capitalize"
              >
                {currentUnits.map(u => <option key={u} value={u}>{u}</option>)}
              </select>
            </div>
          );
        })}
      </div>
      <div>
        <label className="block text-xs text-gray-400 mb-1">Value</label>
        <input
          type="number"
          value={inputVal}
          onChange={e => setInputVal(e.target.value)}
          placeholder="Enter value…"
          className="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-white text-sm
            focus:outline-none focus:border-violet-500 transition-colors"
        />
      </div>
      <button
        onClick={convert}
        className="w-full py-2 bg-violet-600 hover:bg-violet-500 text-white rounded-lg text-sm font-semibold transition-colors"
      >
        Convert
      </button>
      {output && (
        <div className="p-3 bg-violet-500/10 border border-violet-500/20 rounded-lg text-violet-200 text-sm font-mono">
          {inputVal} {fromUnit} = {output} {toUnit}
        </div>
      )}
    </div>
  );
};

// ─── Examples ────────────────────────────────────────────────────────────────

interface ExamplesSectionProps { onLoad: (expr: string) => void; }

const ExamplesSection: React.FC<ExamplesSectionProps> = ({ onLoad }) => (
  <div className="space-y-2">
    {EXAMPLE_CALCULATIONS.map((ex, i) => (
      <button
        key={i}
        onClick={() => onLoad(ex.expression)}
        className="w-full flex items-center justify-between p-2.5 rounded-lg bg-black/30 hover:bg-white/5
          border border-white/5 hover:border-white/15 transition-all text-left group"
      >
        <div>
          <div className="text-gray-500 text-xs">{ex.label}</div>
          <div className="text-white text-sm font-mono">{ex.expression}</div>
        </div>
        <div className="text-violet-400 font-mono text-sm font-bold">= {ex.result}</div>
      </button>
    ))}
  </div>
);

// ─── Main Tools Panel ────────────────────────────────────────────────────────

type Tab = 'examples' | 'percent' | 'stats' | 'convert';

interface ToolsPanelProps { onLoadExample: (expr: string) => void; }

export const ToolsPanel: React.FC<ToolsPanelProps> = ({ onLoadExample }) => {
  const [tab, setTab] = useState<Tab>('examples');

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: 'examples', label: 'Examples', icon: <Zap size={12} />          },
    { id: 'percent',  label: 'Percent',  icon: <Percent size={12} />      },
    { id: 'stats',    label: 'Stats',    icon: <BarChart2 size={12} />    },
    { id: 'convert',  label: 'Convert',  icon: <ArrowLeftRight size={12} /> },
  ];

  return (
    <div className="flex flex-col h-full">
      {/* tabs */}
      <div className="flex border-b border-white/10">
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex-1 flex items-center justify-center gap-1 px-1 py-3 text-xs font-semibold
              transition-colors border-b-2 ${
              tab === t.id
                ? 'border-violet-500 text-violet-400'
                : 'border-transparent text-gray-500 hover:text-gray-300'
            }`}
          >
            {t.icon}
            <span className="hidden sm:inline">{t.label}</span>
          </button>
        ))}
      </div>
      {/* content */}
      <div className="flex-1 overflow-y-auto p-4">
        {tab === 'examples' && <ExamplesSection onLoad={onLoadExample} />}
        {tab === 'percent'  && <PercentageCalculator />}
        {tab === 'stats'    && <StatisticsCalculator />}
        {tab === 'convert'  && <UnitConverter />}
      </div>
    </div>
  );
};
