import React, { useRef, useEffect } from 'react';
import { Copy, CheckCircle } from 'lucide-react';

interface DisplayProps {
  expression: string;
  result: string;
  error: string | null;
  onCopy: () => void;
  copied: boolean;
}

export const Display: React.FC<DisplayProps> = ({
  expression, result, error, onCopy, copied,
}) => {
  const exprRef = useRef<HTMLDivElement>(null);

  // Auto-scroll expression to the end
  useEffect(() => {
    if (exprRef.current) exprRef.current.scrollLeft = exprRef.current.scrollWidth;
  }, [expression]);

  const displayResult = error ?? result;
  const isError = !!error;

  return (
    <div
      className="relative bg-gradient-to-b from-black/40 to-black/60 rounded-2xl p-4 mx-1 mb-2
        border border-white/5 shadow-inner min-h-[120px] flex flex-col justify-between overflow-hidden"
    >
      {/* decorative grid */}
      <div
        className="absolute inset-0 opacity-[0.02] pointer-events-none"
        style={{
          backgroundImage:
            'linear-gradient(rgba(255,255,255,.5) 1px,transparent 1px),' +
            'linear-gradient(90deg,rgba(255,255,255,.5) 1px,transparent 1px)',
          backgroundSize: '20px 20px',
        }}
      />

      {/* Expression row */}
      <div className="relative">
        <p className="text-gray-400 text-[10px] font-mono mb-1 tracking-widest uppercase opacity-60">
          Expression
        </p>
        <div
          ref={exprRef}
          className="text-white text-base font-mono overflow-x-auto whitespace-nowrap pr-4"
          style={{ scrollbarWidth: 'none' }}
          aria-label="Expression"
          role="textbox"
          aria-readonly="true"
        >
          {expression || <span className="text-gray-600">Enter expression…</span>}
        </div>
      </div>

      {/* Result row */}
      <div className="relative mt-2 flex items-end justify-between gap-2">
        <div
          className={`flex-1 text-right font-mono font-bold overflow-x-auto whitespace-nowrap transition-all duration-200
            ${isError ? 'text-red-400 text-sm' : 'text-white text-3xl'}`}
          style={{ scrollbarWidth: 'none' }}
          aria-label={isError ? 'Error' : 'Result'}
          aria-live="polite"
        >
          {displayResult || (!expression ? <span className="text-gray-700 text-2xl">0</span> : null)}
        </div>

        {result && !error && (
          <button
            onClick={onCopy}
            className="flex-shrink-0 p-2 rounded-lg bg-white/5 hover:bg-white/15 text-gray-400
              hover:text-white transition-all duration-200 group"
            aria-label="Copy result"
            title="Copy result"
          >
            {copied
              ? <CheckCircle size={16} className="text-emerald-400" />
              : <Copy size={16} className="group-hover:scale-110 transition-transform" />
            }
          </button>
        )}
      </div>
    </div>
  );
};
