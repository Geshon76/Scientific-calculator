import React, { useEffect, useState, useCallback } from 'react';
import { Display }           from './Display';
import { MemoryPanel }       from './MemoryPanel';
import { ScientificButtons } from './ScientificButtons';
import { BasicButtons }      from './BasicButtons';
import { AngleModeSelector } from './AngleModeSelector';
import { useCalculatorContext } from '../context/CalculatorContext';
import type { Precision } from '../types/calculator';

export const Calculator: React.FC = () => {
  const calc = useCalculatorContext();
  const [copied,       setCopied]       = useState(false);
  const [toastVisible, setToastVisible] = useState(false);

  // ─── Copy result ────────────────────────────────────────────────────────────
  const handleCopy = useCallback(() => {
    if (!calc.result) return;
    navigator.clipboard.writeText(calc.result).then(() => {
      setCopied(true); setToastVisible(true);
      setTimeout(() => { setCopied(false); setToastVisible(false); }, 2000);
    });
  }, [calc.result]);

  // ─── Keyboard handler ────────────────────────────────────────────────────────
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement).tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;

      const k = e.key;
      if (k >= '0' && k <= '9')               { calc.appendToExpression(k);         return; }
      if (k === '+')                            { calc.appendToExpression('+');        return; }
      if (k === '-')                            { calc.appendToExpression('−');        return; }
      if (k === '*')                            { calc.appendToExpression('×');        return; }
      if (k === '/') { e.preventDefault();       calc.appendToExpression('÷');        return; }
      if (k === '(' )                           { calc.appendToExpression('(');        return; }
      if (k === ')' )                           { calc.appendToExpression(')');        return; }
      if (k === '.' )                           { calc.appendToExpression('.');        return; }
      if (k === '^' )                           { calc.appendToExpression('^');        return; }
      if (k === '%' )                           { calc.appendToExpression('%');        return; }
      if (k === '!' )                           { calc.appendToExpression('!');        return; }
      if (k === 'Enter' || k === '=')  { e.preventDefault(); calc.calculate();         return; }
      if (k === 'Escape')               { calc.clearAll();                             return; }
      if (k === 'Backspace')            { calc.deleteLast();                            return; }

      // letter shortcuts (no ctrl/meta)
      if (e.ctrlKey || e.metaKey) {
        if (k.toLowerCase() === 'c') { handleCopy(); return; }
        return;
      }
      switch (k.toLowerCase()) {
        case 'p': calc.appendToExpression('π');      break;
        case 'e': calc.appendToExpression('e');      break;
        case 's': calc.appendToExpression('sin(');   break;
        case 'c': calc.appendToExpression('cos(');   break;
        case 't': calc.appendToExpression('tan(');   break;
        case 'l': calc.appendToExpression('log(');   break;
        case 'n': calc.appendToExpression('ln(');    break;
        case 'r': calc.appendToExpression('sqrt(');  break;
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [calc, handleCopy]);

  return (
    <div className="flex flex-col gap-1 p-2">
      {/* Angle mode + precision */}
      <div className="flex items-center justify-between px-1 mb-1">
        <AngleModeSelector mode={calc.angleMode} onChange={calc.setAngleMode} />
        <div className="flex items-center gap-2">
          <label className="text-gray-500 text-xs" htmlFor="precision-select">Precision:</label>
          <select
            id="precision-select"
            value={calc.precision}
            onChange={e => calc.setPrecision(parseInt(e.target.value) as Precision)}
            className="bg-black/30 border border-white/10 rounded-md px-1.5 py-0.5 text-gray-300 text-xs
              focus:outline-none focus:border-violet-500"
          >
            {([6, 8, 10, 12, 15] as Precision[]).map(p => (
              <option key={p} value={p}>{p} digits</option>
            ))}
          </select>
        </div>
      </div>

      {/* Display */}
      <Display
        expression={calc.expression}
        result={calc.result}
        error={calc.error}
        onCopy={handleCopy}
        copied={copied}
      />

      {/* Memory */}
      <MemoryPanel
        memory={calc.memory}
        hasMemory={calc.hasMemory}
        onMS={calc.memoryStore}
        onMR={calc.memoryRecall}
        onMC={calc.memoryClear}
        onMPlus={calc.memoryAdd}
        onMMinus={calc.memorySubtract}
      />

      {/* Scientific */}
      <ScientificButtons
        isSecondMode={calc.isSecondMode}
        onToggleSecond={() => calc.setIsSecondMode(!calc.isSecondMode)}
        onAppend={calc.appendToExpression}
      />

      <div className="mx-1 border-t border-white/5 my-0.5" />

      {/* Basic */}
      <BasicButtons
        onAppend={calc.appendToExpression}
        onCalculate={calc.calculate}
        onClear={calc.clearAll}
        onDelete={calc.deleteLast}
      />

      {/* Toast */}
      <div
        className={`fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl text-sm font-semibold
          shadow-2xl bg-emerald-500 text-white transition-all duration-300
          ${toastVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'}`}
        role="status"
        aria-live="polite"
      >
        ✓ Copied to clipboard!
      </div>
    </div>
  );
};
