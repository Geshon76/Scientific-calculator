import React from 'react';
import { Trash2, Clock, ChevronRight } from 'lucide-react';
import type { HistoryEntry } from '../types/calculator';

interface HistoryPanelProps {
  history: HistoryEntry[];
  onLoadEntry: (entry: HistoryEntry) => void;
  onClearHistory: () => void;
}

function formatTime(ts: number): string {
  return new Date(ts).toLocaleTimeString('en-US', {
    hour: '2-digit', minute: '2-digit', second: '2-digit',
  });
}

export const HistoryPanel: React.FC<HistoryPanelProps> = ({
  history, onLoadEntry, onClearHistory,
}) => {
  const reversed = [...history].reverse();

  return (
    <div className="flex flex-col h-full">
      {/* header */}
      <div className="flex items-center justify-between p-4 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Clock size={16} className="text-violet-400" />
          <span className="font-semibold text-white text-sm">History</span>
          {history.length > 0 && (
            <span className="px-2 py-0.5 bg-violet-600/30 text-violet-300 text-xs rounded-full">
              {history.length}
            </span>
          )}
        </div>
        {history.length > 0 && (
          <button
            onClick={onClearHistory}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20
              text-rose-400 hover:text-rose-300 text-xs transition-colors"
            aria-label="Clear history"
          >
            <Trash2 size={12} />
            Clear
          </button>
        )}
      </div>

      {/* list */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {reversed.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-32 text-gray-600 text-sm text-center">
            <Clock size={24} className="mb-2 opacity-30" />
            <p>No calculations yet</p>
            <p className="text-xs mt-1 opacity-60">Results appear here</p>
          </div>
        ) : (
          reversed.map(entry => (
            <button
              key={entry.id}
              onClick={() => onLoadEntry(entry)}
              className="w-full text-left p-3 rounded-xl bg-white/5 hover:bg-white/10
                border border-white/5 hover:border-white/15 transition-all duration-150 group"
              aria-label={`Load: ${entry.expression} = ${entry.result}`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <div className="text-gray-400 text-xs font-mono truncate group-hover:text-gray-300 transition-colors">
                    {entry.expression}
                  </div>
                  <div className="text-white font-mono font-bold text-sm mt-0.5 truncate">
                    = {entry.result}
                  </div>
                </div>
                <ChevronRight
                  size={14}
                  className="text-gray-600 group-hover:text-violet-400 mt-1 flex-shrink-0
                    group-hover:translate-x-0.5 transition-all"
                />
              </div>
              <div className="text-gray-600 text-xs mt-1 group-hover:text-gray-500 transition-colors">
                {formatTime(entry.timestamp)}
              </div>
            </button>
          ))
        )}
      </div>
    </div>
  );
};
