import React from 'react';
import { CalculatorButton } from './CalculatorButton';

interface BasicButtonsProps {
  onAppend: (value: string) => void;
  onCalculate: () => void;
  onClear: () => void;
  onDelete: () => void;
}

type BtnDef = {
  label: string;
  value: string;
  variant: 'default' | 'operator' | 'equals' | 'action';
};

const ROWS: BtnDef[][] = [
  [
    { label: '7', value: '7', variant: 'default'  },
    { label: '8', value: '8', variant: 'default'  },
    { label: '9', value: '9', variant: 'default'  },
    { label: '÷', value: '÷', variant: 'operator' },
    { label: '(', value: '(', variant: 'default'  },
    { label: ')', value: ')', variant: 'default'  },
  ],
  [
    { label: '4', value: '4', variant: 'default'  },
    { label: '5', value: '5', variant: 'default'  },
    { label: '6', value: '6', variant: 'default'  },
    { label: '×', value: '×', variant: 'operator' },
    { label: '%', value: '%', variant: 'default'  },
    { label: '±', value: '±', variant: 'default'  },
  ],
  [
    { label: '1',   value: '1',   variant: 'default'  },
    { label: '2',   value: '2',   variant: 'default'  },
    { label: '3',   value: '3',   variant: 'default'  },
    { label: '−',   value: '−',   variant: 'operator' },
    { label: 'AC',  value: 'AC',  variant: 'action'   },
    { label: 'DEL', value: 'DEL', variant: 'action'   },
  ],
  [
    { label: '0', value: '0', variant: 'default'  },
    { label: '.', value: '.', variant: 'default'  },
    { label: '=', value: '=', variant: 'equals'   },
    { label: '+', value: '+', variant: 'operator' },
  ],
];

export const BasicButtons: React.FC<BasicButtonsProps> = ({
  onAppend, onCalculate, onClear, onDelete,
}) => {
  const handle = (value: string) => {
    switch (value) {
      case '=':   onCalculate(); break;
      case 'AC':  onClear();     break;
      case 'DEL': onDelete();    break;
      case '±':   onAppend('(-1)×('); break; // negate
      default:    onAppend(value);    break;
    }
  };

  return (
    <div className="px-1 flex flex-col gap-1">
      {ROWS.map((row, ri) => (
        <div key={ri} className={`grid gap-1 ${ri === 3 ? 'grid-cols-4' : 'grid-cols-6'}`}>
          {row.map(btn => (
            <CalculatorButton
              key={btn.label}
              label={btn.label}
              onClick={() => handle(btn.value)}
              variant={btn.variant}
              id={`basic-${btn.label.replace(/[^a-z0-9]/gi, '_')}`}
            />
          ))}
        </div>
      ))}
    </div>
  );
};
