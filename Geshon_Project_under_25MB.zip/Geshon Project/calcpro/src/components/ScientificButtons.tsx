import React from 'react';
import { CalculatorButton } from './CalculatorButton';

interface ScientificButtonsProps {
  isSecondMode: boolean;
  onToggleSecond: () => void;
  onAppend: (value: string) => void;
}

export const ScientificButtons: React.FC<ScientificButtonsProps> = ({
  isSecondMode, onToggleSecond, onAppend,
}) => {
  const s = isSecondMode;

  // Row 1: 2nd + trig
  const row1 = [
    { label: '2nd',           action: onToggleSecond,                         variant: s ? 'active' : 'second', tooltip: 'Toggle 2nd functions' },
    { label: s ? 'sin⁻¹' : 'sin',   action: () => onAppend(s ? 'sin⁻¹(' : 'sin('),  variant: 'function', tooltip: s ? 'Inverse sine (arcsin)'  : 'Sine'    },
    { label: s ? 'cos⁻¹' : 'cos',   action: () => onAppend(s ? 'cos⁻¹(' : 'cos('),  variant: 'function', tooltip: s ? 'Inverse cosine (arccos)' : 'Cosine'  },
    { label: s ? 'tan⁻¹' : 'tan',   action: () => onAppend(s ? 'tan⁻¹(' : 'tan('),  variant: 'function', tooltip: s ? 'Inverse tangent (arctan)' : 'Tangent' },
    { label: s ? 'sinh⁻¹' : 'sinh', action: () => onAppend(s ? 'sinh⁻¹(' : 'sinh('), variant: 'function', tooltip: s ? 'Inverse hyperbolic sine' : 'Hyperbolic sine'   },
    { label: s ? 'cosh⁻¹' : 'cosh', action: () => onAppend(s ? 'cosh⁻¹(' : 'cosh('), variant: 'function', tooltip: s ? 'Inverse hyperbolic cosine' : 'Hyperbolic cosine' },
    { label: s ? 'tanh⁻¹' : 'tanh', action: () => onAppend(s ? 'tanh⁻¹(' : 'tanh('), variant: 'function', tooltip: s ? 'Inverse hyperbolic tangent' : 'Hyperbolic tangent' },
  ] as const;

  // Row 2: log, root, power, constants, misc
  const row2 = [
    { label: s ? '10ˣ'  : 'log',   action: () => onAppend(s ? '10^(' : 'log('),  variant: 'function', tooltip: s ? '10 to the power x' : 'Log base 10'        },
    { label: s ? 'eˣ'   : 'ln',    action: () => onAppend(s ? 'e^('  : 'ln('),   variant: 'function', tooltip: s ? 'e to the power x'  : 'Natural logarithm'   },
    { label: s ? '∛'    : '√',     action: () => onAppend(s ? '∛('   : 'sqrt('), variant: 'function', tooltip: s ? 'Cube root'          : 'Square root'         },
    { label: s ? 'x³'   : 'x²',    action: () => onAppend(s ? '^3'   : '^2'),    variant: 'function', tooltip: s ? 'Cube (x³)'          : 'Square (x²)'        },
    { label: 'xʸ',                  action: () => onAppend('^'),                  variant: 'function', tooltip: 'x to the power y'                              },
    { label: 'π',                   action: () => onAppend('π'),                  variant: 'constant', tooltip: 'Pi = 3.14159…'                                  },
    { label: 'e',                   action: () => onAppend('e'),                  variant: 'constant', tooltip: "Euler's number = 2.71828…"                      },
    { label: 'φ',                   action: () => onAppend('φ'),                  variant: 'constant', tooltip: 'Golden ratio = 1.61803…'                        },
    { label: '|x|',                 action: () => onAppend('abs('),               variant: 'function', tooltip: 'Absolute value'                                 },
    { label: '1/x',                 action: () => onAppend('1/'),                 variant: 'function', tooltip: 'Reciprocal'                                     },
    { label: 'n!',                  action: () => onAppend('!'),                  variant: 'function', tooltip: 'Factorial'                                       },
    { label: 'log₂',                action: () => onAppend('log₂('),              variant: 'function', tooltip: 'Logarithm base 2'                               },
    { label: 'EXP',                 action: () => onAppend('e^('),                variant: 'function', tooltip: 'e to the power x'                               },
  ] as const;

  return (
    <div className="px-1 mb-1 space-y-1">
      <div className="grid grid-cols-7 gap-1">
        {row1.map((btn, i) => (
          <CalculatorButton
            key={i}
            label={btn.label}
            onClick={btn.action}
            variant={btn.variant as any}
            tooltip={btn.tooltip}
            id={`sci-r1-${i}`}
          />
        ))}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {row2.map((btn, i) => (
          <CalculatorButton
            key={i}
            label={btn.label}
            onClick={btn.action}
            variant={btn.variant as any}
            tooltip={btn.tooltip}
            id={`sci-r2-${i}`}
          />
        ))}
      </div>
    </div>
  );
};
