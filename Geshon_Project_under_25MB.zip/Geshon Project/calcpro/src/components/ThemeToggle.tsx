import React from 'react';
import { Sun, Moon } from 'lucide-react';
import type { Theme } from '../types/calculator';

interface ThemeToggleProps {
  theme: Theme;
  onToggle: () => void;
}

export const ThemeToggle: React.FC<ThemeToggleProps> = ({ theme, onToggle }) => (
  <button
    onClick={onToggle}
    className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 transition-all duration-200
      text-yellow-400 hover:text-yellow-300 group"
    aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
    title={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
  >
    <div className="transition-transform duration-300 group-hover:scale-110">
      {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
    </div>
  </button>
);
