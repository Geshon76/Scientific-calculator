import React from 'react';
import type { AngleMode } from '../types/calculator';

interface AngleModeSelectorProps {
  mode: AngleMode;
  onChange: (mode: AngleMode) => void;
}

const MODES: AngleMode[] = ['DEG', 'RAD', 'GRAD'];

export const AngleModeSelector: React.FC<AngleModeSelectorProps> = ({ mode, onChange }) => (
  <div className="flex bg-black/30 rounded-lg p-0.5 gap-0.5" role="group" aria-label="Angle mode">
    {MODES.map(m => (
      <button
        key={m}
        onClick={() => onChange(m)}
        className={`px-2.5 py-1 text-xs font-bold rounded-md transition-all duration-200 ${
          mode === m
            ? 'bg-violet-600 text-white shadow-lg shadow-violet-500/30'
            : 'text-gray-400 hover:text-white hover:bg-white/10'
        }`}
        aria-pressed={mode === m}
        aria-label={`${m} angle mode`}
      >
        {m}
      </button>
    ))}
  </div>
);
