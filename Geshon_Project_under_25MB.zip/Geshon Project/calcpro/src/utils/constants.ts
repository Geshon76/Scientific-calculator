// App-level constants

export const MATH_CONSTANTS = {
  PI:  Math.PI,
  E:   Math.E,
  PHI: (1 + Math.sqrt(5)) / 2,
} as const;

export const EXAMPLE_CALCULATIONS = [
  { expression: '25 + 15 × 2',  result: '55',          label: 'BODMAS'             },
  { expression: 'sin(90)',       result: '1',            label: 'Sine (DEG)'         },
  { expression: 'cos(60)',       result: '0.5',          label: 'Cosine (DEG)'       },
  { expression: 'tan(45)',       result: '1',            label: 'Tangent (DEG)'      },
  { expression: 'sqrt(144)',     result: '12',           label: 'Square Root'        },
  { expression: '2^10',          result: '1024',         label: 'Power'              },
  { expression: '5!',            result: '120',          label: 'Factorial'          },
  { expression: 'log(1000)',     result: '3',            label: 'Logarithm'          },
  { expression: 'ln(e)',         result: '1',            label: 'Natural Log'        },
  { expression: 'π × 10^2',     result: '314.1592654',  label: 'π × Radius²'        },
] as const;

export const KEYBOARD_SHORTCUTS = [
  { key: '0–9',         action: 'Enter digits'         },
  { key: '+  −  *  /', action: 'Operators'             },
  { key: 'Enter',       action: 'Calculate (=)'        },
  { key: 'Escape',      action: 'Clear all (AC)'       },
  { key: 'Backspace',   action: 'Delete last character'},
  { key: '(  )',        action: 'Parentheses'           },
  { key: '.',           action: 'Decimal point'         },
  { key: 'p',           action: 'Insert π'             },
  { key: 'e',           action: 'Insert e'             },
  { key: 's',           action: 'sin('                 },
  { key: 'c',           action: 'cos('                 },
  { key: 't',           action: 'tan('                 },
  { key: 'l',           action: 'log('                 },
  { key: 'n',           action: 'ln('                  },
  { key: 'r',           action: 'sqrt('                },
  { key: 'Ctrl + C',    action: 'Copy result'          },
] as const;
