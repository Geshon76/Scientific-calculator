import type { AngleMode, Precision } from '../types/calculator';

// ─── Angle conversion ────────────────────────────────────────────────────────

function toRadians(value: number, mode: AngleMode): number {
  switch (mode) {
    case 'DEG':  return value * (Math.PI / 180);
    case 'GRAD': return value * (Math.PI / 200);
    case 'RAD':  return value;
  }
}

function fromRadians(value: number, mode: AngleMode): number {
  switch (mode) {
    case 'DEG':  return value * (180 / Math.PI);
    case 'GRAD': return value * (200 / Math.PI);
    case 'RAD':  return value;
  }
}

// ─── Factorial ───────────────────────────────────────────────────────────────

function factorial(n: number): number {
  if (n < 0)             throw new Error('Factorial of negative number');
  if (!Number.isInteger(n)) throw new Error('Factorial requires an integer');
  if (n > 170)            throw new Error('Number too large for factorial');
  if (n === 0 || n === 1) return 1;
  let result = 1;
  for (let i = 2; i <= n; i++) result *= i;
  return result;
}

// ─── Tokeniser ───────────────────────────────────────────────────────────────

type TokenType = 'number' | 'operator' | 'function' | 'lparen' | 'rparen' | 'constant';

interface Token {
  type: TokenType;
  value: string;
}

// Order matters – longer tokens must be checked first
const FUNCTIONS = [
  'sinh⁻¹', 'cosh⁻¹', 'tanh⁻¹',
  'sin⁻¹',  'cos⁻¹',  'tan⁻¹',
  'sinh',   'cosh',   'tanh',
  'sin',    'cos',    'tan',
  'log₂',  'log₁₀', 'log',
  'ln',    'sqrt',   '∛',
  'abs',   'ceil',   'floor',
  'exp',   '10^',    'e^',
  'cbrt',
];

function tokenize(expr: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;

  while (i < expr.length) {
    const ch = expr[i];

    // whitespace
    if (/\s/.test(ch)) { i++; continue; }

    // number
    if (/[0-9]/.test(ch) || (ch === '.' && /[0-9]/.test(expr[i + 1] ?? ''))) {
      let num = '';
      while (i < expr.length && (/[0-9]/.test(expr[i]) || expr[i] === '.'))
        num += expr[i++];
      tokens.push({ type: 'number', value: num });
      continue;
    }

    // constants
    if (ch === 'π') { tokens.push({ type: 'constant', value: 'π' }); i++; continue; }
    if (ch === 'φ') { tokens.push({ type: 'constant', value: 'φ' }); i++; continue; }

    // 'e' standalone (not part of a function name like 'exp')
    if (ch === 'e' && !/[a-z^]/.test(expr[i + 1] ?? '')) {
      tokens.push({ type: 'constant', value: 'e' }); i++; continue;
    }

    // functions
    let matched = false;
    for (const fn of FUNCTIONS) {
      if (expr.substring(i, i + fn.length) === fn) {
        tokens.push({ type: 'function', value: fn });
        i += fn.length;
        matched = true;
        break;
      }
    }
    if (matched) continue;

    // operators
    if (ch === '+')                 { tokens.push({ type: 'operator', value: '+' }); i++; continue; }
    if (ch === '-' || ch === '−')  { tokens.push({ type: 'operator', value: '-' }); i++; continue; }
    if (ch === '*' || ch === '×')  { tokens.push({ type: 'operator', value: '*' }); i++; continue; }
    if (ch === '/' || ch === '÷')  { tokens.push({ type: 'operator', value: '/' }); i++; continue; }
    if (ch === '^')                 { tokens.push({ type: 'operator', value: '^' }); i++; continue; }
    if (ch === '%')                 { tokens.push({ type: 'operator', value: '%' }); i++; continue; }
    if (ch === '!')                 { tokens.push({ type: 'operator', value: '!' }); i++; continue; }
    if (ch === '(')                 { tokens.push({ type: 'lparen',   value: '(' }); i++; continue; }
    if (ch === ')')                 { tokens.push({ type: 'rparen',   value: ')' }); i++; continue; }

    // skip unknown chars
    i++;
  }

  return tokens;
}

// ─── Recursive-descent parser ────────────────────────────────────────────────

class Parser {
  private pos = 0;
  private readonly tokens: Token[];
  private readonly angleMode: AngleMode;
  constructor(tokens: Token[], angleMode: AngleMode) {
    this.tokens = tokens;
    this.angleMode = angleMode;
  }

  parse(): number {
    const result = this.parseExpr(0);
    return result;
  }

  private peek(): Token | null {
    return this.pos < this.tokens.length ? this.tokens[this.pos] : null;
  }

  private consume(): Token {
    return this.tokens[this.pos++];
  }

  /** Precedence-climbing expression parser */
  private parseExpr(minPrec: number): number {
    let left = this.parseUnary();

    for (;;) {
      const tok = this.peek();
      if (!tok || tok.type !== 'operator') break;
      const [prec, rightAssoc] = this.prec(tok.value);
      if (prec < minPrec) break;
      this.consume();

      // postfix
      if (tok.value === '!') { left = factorial(left); continue; }

      const right = this.parseExpr(rightAssoc ? prec : prec + 1);
      left = this.applyBinary(tok.value, left, right);
    }
    return left;
  }

  private prec(op: string): [number, boolean] {
    switch (op) {
      case '+': case '-': return [1, false];
      case '*': case '/': case '%': return [2, false];
      case '^': return [4, true];
      case '!': return [5, false];
      default:  return [0, false];
    }
  }

  private applyBinary(op: string, l: number, r: number): number {
    switch (op) {
      case '+': return l + r;
      case '-': return l - r;
      case '*': return l * r;
      case '/':
        if (r === 0) throw new Error('Cannot divide by zero');
        return l / r;
      case '^': return Math.pow(l, r);
      case '%': return l % r;
      default:  throw new Error(`Unknown operator: ${op}`);
    }
  }

  private parseUnary(): number {
    const tok = this.peek();
    if (!tok) throw new Error('Unexpected end of expression');
    if (tok.type === 'operator' && tok.value === '-') { this.consume(); return -this.parseUnary(); }
    if (tok.type === 'operator' && tok.value === '+') { this.consume(); return  this.parseUnary(); }
    return this.parsePrimary();
  }

  private parsePrimary(): number {
    const tok = this.peek();
    if (!tok) throw new Error('Unexpected end of expression');

    if (tok.type === 'number') {
      this.consume();
      return parseFloat(tok.value);
    }

    if (tok.type === 'constant') {
      this.consume();
      switch (tok.value) {
        case 'π': return Math.PI;
        case 'e': return Math.E;
        case 'φ': return (1 + Math.sqrt(5)) / 2;
        default:  throw new Error(`Unknown constant: ${tok.value}`);
      }
    }

    if (tok.type === 'function') {
      this.consume();
      const lp = this.peek();
      if (!lp || lp.type !== 'lparen') throw new Error(`Expected '(' after ${tok.value}`);
      this.consume();
      const arg = this.parseExpr(0);
      const rp = this.peek();
      if (!rp || rp.type !== 'rparen') throw new Error('Missing closing parenthesis');
      this.consume();
      return this.applyFn(tok.value, arg);
    }

    if (tok.type === 'lparen') {
      this.consume();
      const val = this.parseExpr(0);
      const rp = this.peek();
      if (!rp || rp.type !== 'rparen') throw new Error('Missing closing parenthesis');
      this.consume();
      return val;
    }

    throw new Error(`Unexpected token: ${tok.value}`);
  }

  private applyFn(name: string, arg: number): number {
    const m = this.angleMode;
    switch (name) {
      case 'sin':    return Math.sin(toRadians(arg, m));
      case 'cos':    return Math.cos(toRadians(arg, m));
      case 'tan': {
        const r = Math.tan(toRadians(arg, m));
        if (Math.abs(r) > 1e15) throw new Error('Undefined (tan of 90°)');
        return r;
      }
      case 'sin⁻¹':
        if (arg < -1 || arg > 1) throw new Error('Invalid input for arcsin (must be −1 to 1)');
        return fromRadians(Math.asin(arg), m);
      case 'cos⁻¹':
        if (arg < -1 || arg > 1) throw new Error('Invalid input for arccos (must be −1 to 1)');
        return fromRadians(Math.acos(arg), m);
      case 'tan⁻¹':  return fromRadians(Math.atan(arg), m);
      case 'sinh':   return Math.sinh(arg);
      case 'cosh':   return Math.cosh(arg);
      case 'tanh':   return Math.tanh(arg);
      case 'sinh⁻¹': return Math.asinh(arg);
      case 'cosh⁻¹':
        if (arg < 1) throw new Error('Invalid input for arccosh (must be ≥ 1)');
        return Math.acosh(arg);
      case 'tanh⁻¹':
        if (arg <= -1 || arg >= 1) throw new Error('Invalid input for arctanh (must be −1 to 1)');
        return Math.atanh(arg);
      case 'log': case 'log₁₀':
        if (arg <= 0) throw new Error('Invalid input for log (must be > 0)');
        return Math.log10(arg);
      case 'log₂':
        if (arg <= 0) throw new Error('Invalid input for log₂ (must be > 0)');
        return Math.log2(arg);
      case 'ln':
        if (arg <= 0) throw new Error('Invalid input for ln (must be > 0)');
        return Math.log(arg);
      case 'sqrt':
        if (arg < 0) throw new Error('Invalid real number (√ of negative)');
        return Math.sqrt(arg);
      case '∛': case 'cbrt': return Math.cbrt(arg);
      case 'abs':   return Math.abs(arg);
      case 'ceil':  return Math.ceil(arg);
      case 'floor': return Math.floor(arg);
      case 'exp': case 'e^': return Math.exp(arg);
      case '10^':   return Math.pow(10, arg);
      default: throw new Error(`Unknown function: ${name}`);
    }
  }
}

// ─── Pre-process ─────────────────────────────────────────────────────────────

function preprocess(expr: string): string {
  return expr
    .replace(/×/g, '*')
    .replace(/÷/g, '/')
    .replace(/−/g, '-')
    .replace(/√/g, 'sqrt');
}

// ─── Public API ──────────────────────────────────────────────────────────────

export function evaluate(expression: string, angleMode: AngleMode): number {
  if (!expression.trim()) throw new Error('Empty expression');
  const tokens = tokenize(preprocess(expression));
  if (tokens.length === 0) throw new Error('Empty expression');
  const result = new Parser(tokens, angleMode).parse();
  if (isNaN(result))      throw new Error('Invalid expression');
  if (!isFinite(result))  throw new Error('Result is infinite');
  return result;
}

export function formatNumber(num: number, precision: Precision): string {
  if (!isFinite(num)) return 'Infinity';
  if (isNaN(num))     return 'NaN';

  const abs = Math.abs(num);

  // Scientific notation for very large / very small
  if (abs !== 0 && (abs >= 1e15 || abs < 1e-9)) {
    return num.toExponential(precision - 1);
  }

  const rounded = parseFloat(num.toPrecision(precision));

  // Comma-separated integer
  if (Number.isInteger(rounded) && abs < 1e15) {
    return rounded.toLocaleString('en-US', { maximumFractionDigits: 0 });
  }

  return parseFloat(rounded.toPrecision(precision)).toString();
}
