import type { HistoryEntry, CalculatorSettings } from '../types/calculator';

const HISTORY_KEY  = 'calcpro_history';
const SETTINGS_KEY = 'calcpro_settings';

// ─── History ─────────────────────────────────────────────────────────────────

export function loadHistory(): HistoryEntry[] {
  try {
    const data = localStorage.getItem(HISTORY_KEY);
    return data ? (JSON.parse(data) as HistoryEntry[]) : [];
  } catch {
    return [];
  }
}

export function saveHistory(history: HistoryEntry[]): void {
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(-100)));
  } catch { /* ignore */ }
}

export function clearHistory(): void {
  try { localStorage.removeItem(HISTORY_KEY); } catch { /* ignore */ }
}

// ─── Settings ────────────────────────────────────────────────────────────────

export function loadSettings(): CalculatorSettings {
  try {
    const data = localStorage.getItem(SETTINGS_KEY);
    if (data) return JSON.parse(data) as CalculatorSettings;
  } catch { /* ignore */ }
  return { angleMode: 'DEG', precision: 10, theme: 'dark' };
}

export function saveSettings(settings: CalculatorSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch { /* ignore */ }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
}
