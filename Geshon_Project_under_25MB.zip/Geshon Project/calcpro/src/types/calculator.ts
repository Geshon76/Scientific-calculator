export type AngleMode = 'DEG' | 'RAD' | 'GRAD';
export type Theme = 'dark' | 'light';
export type Precision = 6 | 8 | 10 | 12 | 15;

export interface HistoryEntry {
  id: string;
  expression: string;
  result: string;
  timestamp: number;
}

export interface CalculatorSettings {
  angleMode: AngleMode;
  precision: Precision;
  theme: Theme;
}

export interface StatResult {
  mean: number;
  median: number;
  min: number;
  max: number;
  sum: number;
  count: number;
  stdDev: number;
}

export type LengthUnit = 'mm' | 'cm' | 'm' | 'km' | 'inch' | 'ft' | 'mile';
export type TemperatureUnit = 'celsius' | 'fahrenheit' | 'kelvin';
export type WeightUnit = 'mg' | 'g' | 'kg' | 'lb' | 'oz';
