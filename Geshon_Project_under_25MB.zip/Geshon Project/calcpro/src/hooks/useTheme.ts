import { useState, useEffect } from 'react';
import type { Theme } from '../types/calculator';
import { loadSettings, saveSettings } from '../utils/storage';

export function useTheme() {
  const [theme, setTheme] = useState<Theme>(() => loadSettings().theme);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle('dark', theme === 'dark');
    const settings = loadSettings();
    saveSettings({ ...settings, theme });
  }, [theme]);

  const toggleTheme = () => setTheme(prev => (prev === 'dark' ? 'light' : 'dark'));

  return { theme, toggleTheme };
}
