import { useState, useEffect, useCallback } from 'react';
import { evaluate, formatNumber } from '../utils/calculatorEngine';
import {
  loadHistory, saveHistory, clearHistory as clearStoredHistory,
  generateId, loadSettings, saveSettings,
} from '../utils/storage';
import type { HistoryEntry, AngleMode, Precision } from '../types/calculator';

export function useCalculator() {
  const settings = loadSettings();

  const [expression,     setExpression]     = useState('');
  const [result,         setResult]         = useState('');
  const [angleMode,      setAngleMode]      = useState<AngleMode>(settings.angleMode);
  const [isSecondMode,   setIsSecondMode]   = useState(false);
  const [memory,         setMemory]         = useState(0);
  const [hasMemory,      setHasMemory]      = useState(false);
  const [error,          setError]          = useState<string | null>(null);
  const [precision,      setPrecision]      = useState<Precision>(settings.precision);
  const [history,        setHistory]        = useState<HistoryEntry[]>(() => loadHistory());
  const [justCalculated, setJustCalculated] = useState(false);

  // Persist settings on change
  useEffect(() => {
    const { theme } = loadSettings();
    saveSettings({ angleMode, precision, theme });
  }, [angleMode, precision]);

  // Live preview while typing
  useEffect(() => {
    if (!expression || justCalculated) return;
    try {
      const val = evaluate(expression, angleMode);
      setResult(formatNumber(val, precision));
      setError(null);
    } catch {
      // silent – don't show errors mid-typing
    }
  }, [expression, angleMode, precision, justCalculated]);

  // ─── Calculate ──────────────────────────────────────────────────────────────
  const calculate = useCallback(() => {
    if (!expression.trim()) return;
    try {
      const val       = evaluate(expression, angleMode);
      const formatted = formatNumber(val, precision);
      setResult(formatted);
      setError(null);

      const entry: HistoryEntry = {
        id: generateId(),
        expression,
        result: formatted,
        timestamp: Date.now(),
      };
      setHistory(prev => {
        const updated = [...prev, entry];
        saveHistory(updated);
        return updated;
      });
      setJustCalculated(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Invalid expression');
      setResult('');
    }
  }, [expression, angleMode, precision]);

  // ─── Append ─────────────────────────────────────────────────────────────────
  const appendToExpression = useCallback((value: string) => {
    setJustCalculated(false);
    setError(null);
    if (justCalculated) {
      const ops = ['+', '-', '×', '÷', '^', '%'];
      setExpression(ops.includes(value) ? prev => prev + value : value);
      return;
    }
    setExpression(prev => prev + value);
  }, [justCalculated]);

  // ─── Clear / Delete ─────────────────────────────────────────────────────────
  const clearAll = useCallback(() => {
    setExpression('');
    setResult('');
    setError(null);
    setIsSecondMode(false);
    setJustCalculated(false);
  }, []);

  const deleteLast = useCallback(() => {
    setJustCalculated(false);
    setError(null);
    setExpression(prev => {
      if (!prev.length) return prev;
      // Remove whole function tokens as one unit
      const fns = [
        'sinh⁻¹(', 'cosh⁻¹(', 'tanh⁻¹(',
        'sin⁻¹(',  'cos⁻¹(',  'tan⁻¹(',
        'sinh(',   'cosh(',   'tanh(',
        'sin(',    'cos(',    'tan(',
        'log₂(',  'log(',    'ln(',
        'sqrt(',   'abs(',    '10^(',  'e^(',  '∛(',
      ];
      for (const fn of fns) {
        if (prev.endsWith(fn)) return prev.slice(0, -fn.length);
      }
      return prev.slice(0, -1);
    });
  }, []);

  const setExpressionDirectly = useCallback((expr: string) => {
    setExpression(expr);
    setError(null);
    setJustCalculated(false);
  }, []);

  // ─── Memory ─────────────────────────────────────────────────────────────────
  const memoryStore    = useCallback(() => {
    if (!result) return;
    setMemory(parseFloat(result.replace(/,/g, '')));
    setHasMemory(true);
  }, [result]);

  const memoryRecall   = useCallback(() => {
    appendToExpression(memory.toString());
  }, [memory, appendToExpression]);

  const memoryClear    = useCallback(() => { setMemory(0); setHasMemory(false); }, []);

  const memoryAdd      = useCallback(() => {
    if (!result) return;
    setMemory(prev => prev + parseFloat(result.replace(/,/g, '')));
    setHasMemory(true);
  }, [result]);

  const memorySubtract = useCallback(() => {
    if (!result) return;
    setMemory(prev => prev - parseFloat(result.replace(/,/g, '')));
    setHasMemory(true);
  }, [result]);

  // ─── History ────────────────────────────────────────────────────────────────
  const clearHistoryAll  = useCallback(() => { setHistory([]); clearStoredHistory(); }, []);
  const loadFromHistory  = useCallback((entry: HistoryEntry) => setExpressionDirectly(entry.expression), [setExpressionDirectly]);

  return {
    expression, result, angleMode, isSecondMode,
    memory, hasMemory, error, precision, history,
    setAngleMode,
    setIsSecondMode,
    setPrecision,
    calculate,
    appendToExpression,
    clearAll,
    deleteLast,
    setExpressionDirectly,
    memoryStore, memoryRecall, memoryClear, memoryAdd, memorySubtract,
    clearHistoryAll, loadFromHistory,
  };
}
