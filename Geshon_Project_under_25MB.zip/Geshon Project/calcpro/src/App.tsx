import React, { useState } from 'react';
import { Calculator }           from './components/Calculator';
import { HistoryPanel }         from './components/HistoryPanel';
import { ToolsPanel }           from './components/ToolsPanel';
import { ThemeToggle }          from './components/ThemeToggle';
import { Modal }                from './components/Modal';
import { useTheme }             from './hooks/useTheme';
import { useCalculatorContext, CalculatorProvider } from './context/CalculatorContext';
import { KEYBOARD_SHORTCUTS }  from './utils/constants';
import {
  History, Wrench, Keyboard, Info, Calculator as CalcIcon,
} from 'lucide-react';

type SidePanel = 'history' | 'tools' | null;

// ─── Inner app (uses context) ─────────────────────────────────────────────────

const AppInner: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const calc = useCalculatorContext();

  const [sidePanel,    setSidePanel]    = useState<SidePanel>('history');
  const [showKeyboard, setShowKeyboard] = useState(false);
  const [showAbout,    setShowAbout]    = useState(false);

  const togglePanel = (panel: SidePanel) =>
    setSidePanel(prev => prev === panel ? null : panel);

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      theme === 'dark'
        ? 'bg-gradient-to-br from-gray-950 via-gray-900 to-indigo-950'
        : 'bg-gradient-to-br from-slate-100 via-white to-indigo-50'
    }`}>

      {/* Background glows */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-violet-600/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-purple-600/5 rounded-full blur-3xl" />
      </div>

      <div className="relative min-h-screen flex flex-col">

        {/* ═══ HEADER ═══════════════════════════════════════════════════════════ */}
        <header className={`sticky top-0 z-30 backdrop-blur-xl border-b transition-colors duration-300 ${
          theme === 'dark'
            ? 'bg-gray-950/80 border-white/5'
            : 'bg-white/80 border-gray-200'
        }`}>
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">

            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-gradient-to-br from-violet-500 to-indigo-600 rounded-xl
                flex items-center justify-center shadow-lg shadow-violet-500/30 ring-1 ring-violet-400/30">
                <CalcIcon size={18} className="text-white" />
              </div>
              <div>
                <h1 className={`text-xl font-black tracking-tight leading-none ${
                  theme === 'dark' ? 'text-white' : 'text-gray-900'
                }`}>
                  Calc<span className="text-violet-500">Pro</span>
                </h1>
                <p className={`text-[11px] leading-none mt-0.5 font-medium ${
                  theme === 'dark' ? 'text-gray-500' : 'text-gray-400'
                }`}>
                  Scientific Calculator
                </p>
              </div>
            </div>

            {/* Nav actions */}
            <nav className="flex items-center gap-1.5" aria-label="Main navigation">
              {/* History */}
              <button
                onClick={() => togglePanel('history')}
                aria-pressed={sidePanel === 'history'}
                aria-label="Toggle calculation history"
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 ${
                  sidePanel === 'history'
                    ? 'bg-violet-600 text-white shadow-lg shadow-violet-500/30'
                    : theme === 'dark'
                    ? 'bg-white/10 text-gray-300 hover:bg-white/20 hover:text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <History size={14} />
                <span className="hidden sm:inline">History</span>
                {calc.history.length > 0 && (
                  <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                    sidePanel === 'history'
                      ? 'bg-white/20 text-white'
                      : 'bg-violet-600/30 text-violet-300'
                  }`}>
                    {calc.history.length}
                  </span>
                )}
              </button>

              {/* Tools */}
              <button
                onClick={() => togglePanel('tools')}
                aria-pressed={sidePanel === 'tools'}
                aria-label="Toggle tools panel"
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 ${
                  sidePanel === 'tools'
                    ? 'bg-violet-600 text-white shadow-lg shadow-violet-500/30'
                    : theme === 'dark'
                    ? 'bg-white/10 text-gray-300 hover:bg-white/20 hover:text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <Wrench size={14} />
                <span className="hidden sm:inline">Tools</span>
              </button>

              {/* Keyboard shortcuts */}
              <button
                onClick={() => setShowKeyboard(true)}
                aria-label="Show keyboard shortcuts"
                title="Keyboard shortcuts"
                className={`p-2.5 rounded-xl transition-all duration-200 ${
                  theme === 'dark'
                    ? 'bg-white/10 text-gray-300 hover:bg-white/20 hover:text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <Keyboard size={16} />
              </button>

              {/* About */}
              <button
                onClick={() => setShowAbout(true)}
                aria-label="About CalcPro"
                title="About"
                className={`p-2.5 rounded-xl transition-all duration-200 ${
                  theme === 'dark'
                    ? 'bg-white/10 text-gray-300 hover:bg-white/20 hover:text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <Info size={16} />
              </button>

              <ThemeToggle theme={theme} onToggle={toggleTheme} />
            </nav>
          </div>
        </header>

        {/* ═══ MAIN CONTENT ════════════════════════════════════════════════════ */}
        <main className="flex-1 flex items-start justify-center p-4 pt-6">
          <div className="w-full max-w-6xl flex gap-4 items-start justify-center">

            {/* Calculator card */}
            <div className={`flex-shrink-0 w-full max-w-[440px] rounded-2xl shadow-2xl overflow-hidden transition-all duration-300 ${
              theme === 'dark'
                ? 'bg-gray-900/95 border border-white/10 shadow-black/50'
                : 'bg-white/95 border border-gray-200/80 shadow-gray-300/40'
            }`}>
              <Calculator />
            </div>

            {/* Side panel — desktop */}
            {sidePanel && (
              <div
                className={`hidden md:flex flex-col rounded-2xl shadow-2xl overflow-hidden
                  w-80 flex-shrink-0 transition-all duration-300 ${
                  theme === 'dark'
                    ? 'bg-gray-900/95 border border-white/10 shadow-black/50'
                    : 'bg-white/95 border border-gray-200/80 shadow-gray-300/40'
                }`}
                style={{ maxHeight: 'calc(100vh - 100px)', minHeight: '400px' }}
              >
                {sidePanel === 'history'
                  ? <HistoryPanel
                      history={calc.history}
                      onLoadEntry={calc.loadFromHistory}
                      onClearHistory={calc.clearHistoryAll}
                    />
                  : <ToolsPanel onLoadExample={calc.setExpressionDirectly} />
                }
              </div>
            )}
          </div>
        </main>

        {/* Side panel — mobile bottom sheet */}
        {sidePanel && (
          <div
            className={`md:hidden fixed bottom-0 left-0 right-0 z-20 rounded-t-2xl shadow-2xl
              overflow-hidden ${
              theme === 'dark'
                ? 'bg-gray-900 border-t border-white/10'
                : 'bg-white border-t border-gray-200'
            }`}
            style={{ maxHeight: '50vh' }}
          >
            {sidePanel === 'history'
              ? <HistoryPanel
                  history={calc.history}
                  onLoadEntry={calc.loadFromHistory}
                  onClearHistory={calc.clearHistoryAll}
                />
              : <ToolsPanel onLoadExample={calc.setExpressionDirectly} />
            }
          </div>
        )}
      </div>

      {/* ═══ KEYBOARD SHORTCUTS MODAL ════════════════════════════════════════ */}
      <Modal isOpen={showKeyboard} onClose={() => setShowKeyboard(false)} title="⌨️ Keyboard Shortcuts">
        <div className="space-y-1">
          {KEYBOARD_SHORTCUTS.map(({ key, action }) => (
            <div key={key} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
              <span className="text-gray-400 text-sm">{action}</span>
              <kbd className="px-2 py-1 bg-gray-800 border border-gray-600 rounded-lg text-gray-200 text-xs font-mono min-w-[56px] text-center">
                {key}
              </kbd>
            </div>
          ))}
        </div>
      </Modal>

      {/* ═══ ABOUT MODAL ═════════════════════════════════════════════════════ */}
      <Modal isOpen={showAbout} onClose={() => setShowAbout(false)} title="About CalcPro">
        <div className="space-y-5">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-gradient-to-br from-violet-500 to-indigo-600 rounded-2xl
              flex items-center justify-center shadow-lg shadow-violet-500/30 flex-shrink-0">
              <CalcIcon size={32} className="text-white" />
            </div>
            <div>
              <h2 className="text-white text-2xl font-black">CalcPro</h2>
              <p className="text-gray-400 text-sm">Scientific Calculator Web Application</p>
              <span className="inline-block mt-1 px-2 py-0.5 bg-violet-600/20 text-violet-400 text-xs rounded-full border border-violet-500/30">
                v1.0.0
              </span>
            </div>
          </div>

          <p className="text-gray-400 text-sm leading-relaxed">
            A modern, fully-functional scientific calculator built with{' '}
            <strong className="text-white">React, TypeScript, Vite</strong> and{' '}
            <strong className="text-white">Tailwind CSS v4</strong>.
            Uses a custom safe expression parser — <strong className="text-white">no eval()</strong> is used.
          </p>

          <div>
            <h3 className="text-white text-sm font-bold mb-3 flex items-center gap-2">
              <span className="w-1 h-4 bg-violet-500 rounded-full" />
              Features
            </h3>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1">
              {[
                '✓ Scientific calculations',
                '✓ sin, cos, tan + inverses',
                '✓ Hyperbolic functions',
                '✓ log, ln, log₂',
                '✓ Powers & roots (√, ∛, xʸ)',
                '✓ Factorial & absolute value',
                '✓ Constants: π, e, φ',
                '✓ Memory: MC/MR/MS/M+/M−',
                '✓ Calculation history',
                '✓ Keyboard shortcuts',
                '✓ Dark / light theme',
                '✓ Responsive design',
                '✓ Unit converter',
                '✓ Statistics calculator',
                '✓ Percentage calculator',
                '✓ Copy to clipboard',
              ].map(f => (
                <div key={f} className="text-gray-400 text-xs py-0.5">{f}</div>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-white/10 text-center">
            <p className="text-gray-600 text-xs">
              React 19 · TypeScript 6 · Vite 8 · Tailwind CSS v4 · Lucide React
            </p>
          </div>
        </div>
      </Modal>
    </div>
  );
};

// ─── Root (wraps with context provider) ──────────────────────────────────────

const App: React.FC = () => (
  <CalculatorProvider>
    <AppInner />
  </CalculatorProvider>
);

export default App;
